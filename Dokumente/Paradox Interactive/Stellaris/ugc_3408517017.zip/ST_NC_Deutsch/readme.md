Übersetzung für den Star Trek: New Civilisations Mod (Star Trek: New Civilisations - 2026-06-18)

https://steamcommunity.com/sharedfiles/filedetails/?id=1886496498

Mein Dank geht an die tolle Arbeit der Star Trek: New Civilisations Entwickler.

History
Datum			Version			Beschreibung

2026-06-19		2026-06-18		Update für Version vom 2026-06-18
2026-06-11		2026-05-31		Update für Version vom 2026-05-31
2026-01-11		2026-01-06		Update für Version vom 2026-01-06
2025-02-04		1.0.1			Update für Version vom 2025-02-03
2025-01-16		1.0.0			Erstübersetzung von Version 2025-01-15