Übersetzung für den Star Trek: New Civilisations Mod (Star Trek: New Civilisations - 2025-01-15)

https://steamcommunity.com/sharedfiles/filedetails/?id=1886496498

Mein Dank geht an die tolle Arbeit der Star Trek: New Civilisations Entwickler.

History

2025-01-16		1.0.0			Erstübersetzung von Version 2025-01-15