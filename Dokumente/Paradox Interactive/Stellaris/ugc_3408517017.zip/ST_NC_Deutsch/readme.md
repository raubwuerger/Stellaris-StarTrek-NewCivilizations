Übersetzung für den Star Trek: New Civilisations Mod (Star Trek: New Civilisations - 2025-02-03)

https://steamcommunity.com/sharedfiles/filedetails/?id=1886496498

Mein Dank geht an die tolle Arbeit der Star Trek: New Civilisations Entwickler.

History

2025-02-04		1.0.1			Update für Version von 2025-02-03
2025-01-16		1.0.0			Erstübersetzung von Version 2025-01-15