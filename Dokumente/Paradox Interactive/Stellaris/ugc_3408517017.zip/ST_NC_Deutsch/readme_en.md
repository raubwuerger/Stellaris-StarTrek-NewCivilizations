Translation for the Star Trek: New Civilisations Mod (Star Trek: New Civilisations - 2025-01-15)

https://steamcommunity.com/sharedfiles/filedetails/?id=1886496498

My thanks go to the great work of the Star Trek: New Civilisations developers.

History

2025-01-16		1.0.0			First translation of version 2025-01-15