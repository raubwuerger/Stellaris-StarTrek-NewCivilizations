Translation for the Star Trek: New Civilisations Mod (Star Trek: New Civilisations - 2026-06-18)

https://steamcommunity.com/sharedfiles/filedetails/?id=1886496498

My thanks go to the great work of the Star Trek: New Civilisations developers.

History
Date			Version			Description

2026-06-19		2026-06-18		Update for version from 2026-06-18
2026-06-11		2026-05-31		Update for version from 2026-05-31
2026-01-11		2026-01-06		Update for version from 2026-01-06
2025-02-04		1.0.1			Update for version from 2025-02-03
2025-01-16		1.0.0			First translation of version 2025-01-15