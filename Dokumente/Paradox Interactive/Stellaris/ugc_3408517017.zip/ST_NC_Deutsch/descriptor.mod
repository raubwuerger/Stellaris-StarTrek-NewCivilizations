version="1.0.1"
tags={
	"Translation"
}
name="Star Trek: New Civilisations - Deutsch"
picture="Thumbnail.jpg"
supported_version="v4.0.*"
remote_file_id="3408517017"