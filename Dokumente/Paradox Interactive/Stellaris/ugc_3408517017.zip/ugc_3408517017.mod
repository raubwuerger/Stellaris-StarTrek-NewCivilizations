version="1.0.1"
tags={
	"Translation"
}
name="Star Trek: New Civilisations - Deutsch"
picture="Thumbnail.jpg"
supported_version="v4.1.*"
path="D:/Spiele/SteamLibrary/steamapps/workshop/content/281990/3408517017"
remote_file_id="3408517017"